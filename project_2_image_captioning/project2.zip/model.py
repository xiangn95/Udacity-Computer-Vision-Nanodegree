import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
from pdb import set_trace

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class EncoderCNN(nn.Module):
    def __init__(self, embed_size):
        super(EncoderCNN, self).__init__()
        resnet = models.resnet50(pretrained=True)
        for param in resnet.parameters():
            param.requires_grad_(False)
            
        modules = list(resnet.children())[:-1]

        self.resnet = nn.Sequential(*modules)
        self.embed = nn.Linear(resnet.fc.in_features, embed_size)

    def forward(self, images):
        features = self.resnet(images)
        features = features.view(features.size(0), -1)
        features = self.embed(features)
        return features


class DecoderRNN(nn.Module):
    def __init__(self, embed_size, hidden_size, vocab_size, batch_size, num_layers=1):
        super().__init__()

        self.n_layers = num_layers
        self.n_hidden = hidden_size
        self.batch_size = batch_size
        self.vocab_size = vocab_size

        self.embedding = nn.Embedding(vocab_size, embed_size)
        self.lstm = nn.LSTM(embed_size, hidden_size=hidden_size, 
                            num_layers=num_layers, batch_first=True)
        
        self.fc = nn.Linear(hidden_size, vocab_size)
        
        self.init_weights()
        self.init_hidden_state()
        
    def forward(self, features, captions):

        captions = captions[:, :-1]

        captions = self.embedding(captions)

        
        x = torch.cat((features.unsqueeze(1), captions), dim=1) 
        x, (self.h, self.c) = self.lstm(x, (self.h, self.c))
        x = self.fc(x)
        
        self.h = self.h.detach()
        self.c = self.c.detach()
        return x
    
    # Reference from https://github.com/sgrvinod/a-PyTorch-Tutorial-to-Image-Captioning/blob/master/models.py
    def init_weights(self):
        """
        Initializes some parameters with values from the uniform distribution, for easier convergence.
        """
        self.embedding.weight.data.uniform_(-0.1, 0.1)
        self.fc.bias.data.fill_(0)
        self.fc.weight.data.uniform_(-0.1, 0.1)
        

    
    def init_hidden_state(self):
        self.h = torch.zeros(self.n_layers, self.batch_size, self.n_hidden).to(device)
        self.c = torch.zeros(self.n_layers, self.batch_size, self.n_hidden).to(device)
        

    def sample(self, inputs, states=None, max_len=20):
        word_list = []
        inputs = inputs.squeeze(1).float() # (1, embed_size)
        h,c = self.init_hidden_state(inputs)
         
        # Need to force the first word as <start>
        
        for i in range(max_len):            

            h, c = self.lstm(inputs, (h, c))
            
            output = F.log_softmax(self.fc(h), dim=1)

            _, next_word = torch.topk(output, 1)
            word_list.append(next_word.cpu().detach().item())
            inputs = self.embedding(next_word).squeeze(1)
            if next_word.item() == 1:
                break
        return word_list
            
            
            